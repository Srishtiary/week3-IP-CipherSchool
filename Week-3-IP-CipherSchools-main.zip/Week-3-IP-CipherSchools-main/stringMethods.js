let name = 'Harsha'
upper = name.toUpperCase()
console.log(upper)

// typeof funciton

console.log(typeof name)

// string slicing
console.log(name.slice(0,4))

// convert string to number
name = +name
// convert number to string
name = name +""
// string concatenation

let firstName = 'Harsha'
let lastname = 'Sai'
let fullName = firstName + lastname
console.log(fullName)

// template strings 
// this is like formatted strings in python but the syntax is different
let age = 17
let aboutMe = `My name is ${name} and my age is ${age}`
let aboutMe = `My name is ${name} and my age is ${age}`
